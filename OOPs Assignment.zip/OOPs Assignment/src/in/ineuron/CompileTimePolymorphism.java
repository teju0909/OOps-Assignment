package in.ineuron;
class Animal1 {
    void speak() {
        System.out.println("I am an animal");
    }
}

class Dog1 extends Animal1 {
    void speak() {
        System.out.println("Woof!");
    }
}

class Cat1 extends Animal1 {
    void speak() {
        System.out.println("Meow!");
    }
}

public class CompileTimePolymorphism {
    public static void main(String[] args) {
        Animal1 animal = new Dog1();
        animal.speak();

        Animal1 animal2 = new Cat1();
        animal2.speak();
    }
}